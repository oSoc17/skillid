<template>
  <div id="app-badge-container">
    <h1>Badge</h1>

    <svg class="svg-badge">
    </svg>

    <div class="buttons">
      <button type="button" name="button">Download</button>
      <button type="button" name="button">Store</button>
      <button type="button" name="button">Issue</button>
    </div>
  </div>

</template>

<style src="../css/app-badge.css"></style>
<script src="../js/app-badge.js"></script>
