export default {
  name: 'app-badge',
  data: function () {
    return {

     }
   }

}
