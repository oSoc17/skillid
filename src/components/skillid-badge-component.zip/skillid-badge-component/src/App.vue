<template>
  <div id="app">
    <h1>Skillid</h1>
    <div class="content-container">
      <app-badge></app-badge>
      <app-form></app-form>
    </div>

  </div>
</template>

<script src="./js/app.js"></script>
<style src="./css/app.css"></style>
